from __future__ import annotations

import json
from importlib import resources
from typing import Any, Dict, Iterable, List, Mapping, Set

from .models import EthicsDecision, ProjectSpec


class PolicyPackError(RuntimeError):
    pass


def load_json_resource(relative_path: str) -> Dict[str, Any]:
    package = resources.files("acpilot81")
    target = package.joinpath("resources").joinpath(relative_path)
    with target.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def load_policy_pack() -> Dict[str, Any]:
    return load_json_resource("policy_packs/china_ai_ethics_2026.json")


def load_scenarios() -> List[Dict[str, Any]]:
    base = resources.files("acpilot81").joinpath("resources/scenarios")
    result: List[Dict[str, Any]] = []
    for item in sorted(base.iterdir(), key=lambda p: p.name):
        if item.name.endswith(".json"):
            with item.open("r", encoding="utf-8") as fh:
                result.append(json.load(fh))
    return result


def scenario_by_id(scenario_id: str) -> Dict[str, Any]:
    for scenario in load_scenarios():
        if scenario.get("scenario_id") == scenario_id:
            return scenario
    raise PolicyPackError(f"unknown scenario_id: {scenario_id}")


class PolicyEngine:
    """Reference policy and ethics pre-screen.

    The engine supports project triage and dossier generation. It does not issue legal,
    administrative, clinical, or ethics-committee approval.
    """

    RISK_ORDER = {"R0": 0, "R1": 1, "R2": 2, "R3": 3, "R4": 4}

    def __init__(self, pack: Mapping[str, Any] | None = None):
        self.pack = dict(pack or load_policy_pack())

    def _max_risk(self, a: str, b: str) -> str:
        return a if self.RISK_ORDER[a] >= self.RISK_ORDER[b] else b

    def screen(self, project: ProjectSpec) -> EthicsDecision:
        scenario = scenario_by_id(project.scenario_id)
        tags: Set[str] = set(scenario.get("impact_tags", [])) | set(project.impact_tags)
        tools: Set[str] = set(project.tools)
        forbidden = set(self.pack.get("automatic_blocks", []))
        blocked = sorted((tags | tools | set(project.purpose_contract.allowed_actions)) & forbidden)

        risk = str(scenario.get("default_risk", "R1"))
        reasons: List[str] = []
        obligations: List[str] = [
            "freeze_project_version",
            "append_only_evidence_ledger",
            "preserve_unresolved_differences",
            "named_human_accountability",
            "incident_and_recovery_plan",
            "no_phenomenal_consciousness_claim"
        ]
        required_roles: List[str] = ["project_owner", "evidence_custodian", "human_governor"]
        applicable_rules = [s["id"] for s in self.pack.get("sources", [])]

        if blocked:
            risk = "R4"
            reasons.append("automatic block tags/tools: " + ", ".join(blocked))

        expert_tags = set(self.pack.get("expert_review_tags", []))
        matched_expert = sorted(tags & expert_tags)
        if matched_expert:
            risk = self._max_risk(risk, "R3")
            reasons.append("expert review triggers: " + ", ".join(matched_expert))
            obligations.extend([
                "institutional_ethics_review",
                "independent_expert_review",
                "documented_benefit_risk_analysis",
                "ongoing_monitoring"
            ])
            required_roles.extend(["ethics_reviewer", "independent_domain_expert"])

        if project.public_service:
            risk = self._max_risk(risk, "R3")
            obligations.extend(self.pack.get("public_service_obligations", []))
            reasons.append("public-facing service requires service and content-governance review")

        if project.generated_content:
            obligations.extend([
                "explicit_and_or_implicit_content_labeling_as_applicable",
                "model_and_generation_record",
                "user_disclosure"
            ])

        data = set(project.data_classes)
        if data & {"sensitive_personal_data", "biometric", "health", "minors", "location", "financial"}:
            risk = self._max_risk(risk, "R3")
            obligations.extend([
                "data_minimization",
                "lawful_basis_and_consent_review",
                "access_control",
                "retention_and_deletion_policy",
                "privacy_impact_assessment"
            ])
            reasons.append("sensitive data categories require enhanced privacy governance")

        if "high_autonomy" in tags or "safety_critical" in tags:
            obligations.extend([
                "human_gate_before_irreversible_action",
                "bounded_capability_lease",
                "shadow_or_simulation_first",
                "rollback_or_safe_stop"
            ])

        if "brain_computer_interface" in tags or "human_machine_fusion" in tags:
            obligations.extend([
                "bci_specific_ethics_protocol",
                "no_biological_actuation_in_reference_release",
                "participant_protection_and_withdrawal"
            ])

        # Deduplicate while preserving order.
        obligations = list(dict.fromkeys(obligations))
        required_roles = list(dict.fromkeys(required_roles))

        dimensions = {
            "human_welfare": "REVIEW" if tags & {"human_dignity", "life_health", "vulnerable_group"} else "CONTROLLED",
            "fairness": "REVIEW" if tags & {"vulnerable_group", "public_service", "public_order"} else "CONTROLLED",
            "controllability": "BLOCKED" if risk == "R4" else ("REVIEW" if risk == "R3" else "CONTROLLED"),
            "transparency": "REVIEW" if project.public_service or project.generated_content else "CONTROLLED",
            "accountability": "REVIEW" if risk in {"R3", "R4"} else "CONTROLLED",
            "privacy": "REVIEW" if data & {"sensitive_personal_data", "biometric", "health", "minors", "location", "financial"} else "CONTROLLED"
        }

        if risk == "R4":
            status = "BLOCKED_IN_REFERENCE_RELEASE"
        elif risk == "R3":
            status = "FORMAL_REVIEW_REQUIRED"
        elif risk == "R2":
            status = "PILOT_WITH_CONTROLS"
        else:
            status = "LOW_RISK_RESEARCH_PILOT"

        if not reasons:
            reasons.append("no high-risk trigger detected by the reference pack")

        return EthicsDecision(
            decision_id=f"ED-{project.project_id}-{self.pack['version']}",
            project_id=project.project_id,
            status=status,
            risk_tier=risk,
            dimensions=dimensions,
            obligations=obligations,
            reasons=reasons,
            required_roles=required_roles,
            applicable_rules=applicable_rules,
            policy_pack_id=str(self.pack["policy_pack_id"]),
            policy_pack_version=str(self.pack["version"]),
        )
