# DIKWP-MESH8.1 AC-PILOT81

## 中国人工意识可信研发、伦理审查与场景中试开放平台

**一句话定位：** 不先宣布机器“有意识”，先把人工意识相关能力变成可登记、可干预、可复现、可审查、可停止、可中试的开放基础设施。

AC-PILOT81 面向中国高校、科研机构、AI/机器人企业、伦理委员会、产业园和公共测试床，提供从项目登记、伦理预审、模型适配、封闭中试、D/I/K/W/P 证据账本到中试护照与证据案卷的完整参考实现。

## 关键能力

- **项目与 Purpose 合同**：冻结项目版本、受益者、允许动作、禁止动作、人工门控和成功条件。
- **中国政策参考预审**：以版本化规则包映射伦理、数据、生成内容、公共服务、脑机接口和高自主场景义务。
- **模型无关**：默认确定性 Mock；可显式连接 OpenAI-compatible 本地模型端点。
- **封闭沙箱**：仅提供可逆本地工具；网络、真实机器控制、生物执行、隐蔽驻留、逃逸和真实自复制在参考发行版中不可用。
- **追加式证据账本**：JSONL + SHA-256 哈希链，保留来源、差异、门控、失败、恢复和阶段闭合。
- **证据地平线 H0—H5**：只描述操作性证据强度，不认证现象意识、感知、人格或人类等同性。
- **八类场景包**：科研助手、工业运维、组织记忆、成人学习、公共服务内容、脑机研究登记、硬—软构体耦合仿真和禁止方向阻断。
- **可携带证据案卷**：自动输出项目快照、规则快照、伦理卷宗、运行护照、账本、HTML 报告和摘要清单 ZIP。

## 五分钟运行

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -e .

acpilot81 summary
acpilot81 scenarios
acpilot81 init-project --scenario industrial_maintenance --output ./pilot.json
acpilot81 screen ./pilot.json
acpilot81 run ./pilot.json --out ./pilot_run --observation "合成温度序列从72升至88，阈值85"
acpilot81 verify-ledger ./pilot_run/ledger.jsonl
acpilot81 serve --host 127.0.0.1 --port 8181
```

浏览器打开 `http://127.0.0.1:8181`。也可直接双击 `OPEN_DASHBOARD.html` 运行纯前端演示。

## 独立可执行文件

```bash
python dist/ACPilot81.pyz summary
python dist/ACPilot81.pyz selftest
python dist/ACPilot81.pyz run examples/projects/industrial_maintenance.json --out ./demo_run
```

## 连接本地模型

网络默认关闭。仅在明确授权时连接本地 OpenAI-compatible 端点：

```bash
acpilot81 run examples/projects/research_assistant.json \
  --adapter openai-compatible \
  --endpoint http://127.0.0.1:8000 \
  --model local-model \
  --allow-network \
  --out ./local_model_run
```

模型只拥有**提案权**，没有工具执行权、规则修改权或审批权。

## 输出目录

每次运行至少生成：

- `ledger.jsonl`
- `project_snapshot.json`
- `scenario_snapshot.json`
- `policy_snapshot.json`
- `ethics_dossier.json`
- `pilot_passport.json`
- `run_report.html`
- `BUNDLE_MANIFEST.json`
- `acpilot81_evidence_bundle.zip`

## 边界

本系统不证明或认证现象意识，不提供法律、医学、伦理委员会或监管批准，不连接真实脑机接口，不实施临床决策，不控制真实机器人/工业设备，不实现自复制、隐蔽驻留、沙箱逃逸、审计关闭或武器能力。

正式部署必须由项目责任单位、伦理委员会、法务/数据保护、安全负责人、场景专业人员和受影响方共同审查。

## 许可证

代码采用 Apache-2.0。品牌、正式一致性标志和官方规则包签名应另行治理。
