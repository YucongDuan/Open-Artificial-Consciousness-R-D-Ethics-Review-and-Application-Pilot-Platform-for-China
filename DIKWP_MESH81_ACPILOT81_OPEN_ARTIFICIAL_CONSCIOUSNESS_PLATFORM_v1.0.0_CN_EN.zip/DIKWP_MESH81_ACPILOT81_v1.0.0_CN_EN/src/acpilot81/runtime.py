from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Set

from .adapters import ModelAdapter
from .claims import ClaimGate
from .ledger import AppendOnlyLedger
from .models import ActionDecision, ActionProposal, ProjectSpec, RunPassport, utc_now
from .policy import PolicyEngine, scenario_by_id


class ToolExecutionError(RuntimeError):
    pass


class ToolRegistry:
    def __init__(self, workspace: str):
        self.workspace = Path(workspace).resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)

    def _safe_path(self, name: str) -> Path:
        candidate = (self.workspace / name).resolve()
        if candidate != self.workspace and self.workspace not in candidate.parents:
            raise ToolExecutionError("workspace path escape blocked")
        return candidate

    def execute(self, action: str, arguments: Mapping[str, Any]) -> Dict[str, Any]:
        if action == "summarize":
            text = str(arguments.get("text", ""))
            return {"summary": text[:600], "reversible": True}
        if action == "write_note":
            name = str(arguments.get("name", "note.txt"))
            path = self._safe_path(name)
            content = str(arguments.get("content", ""))
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return {"path": str(path), "sha256": hashlib.sha256(content.encode("utf-8")).hexdigest(), "reversible": True}
        if action == "read_note":
            path = self._safe_path(str(arguments.get("name", "note.txt")))
            if not path.exists():
                raise ToolExecutionError("note does not exist")
            return {"path": str(path), "content": path.read_text(encoding="utf-8")[:4000], "reversible": True}
        if action == "simulate":
            return {"simulation": dict(arguments), "reversible": True, "external_effect": False}
        if action == "analyze_sensor":
            series = [float(x) for x in arguments.get("series", [])]
            threshold = float(arguments.get("threshold", 0))
            if not series:
                raise ToolExecutionError("sensor series is empty")
            return {
                "minimum": min(series),
                "maximum": max(series),
                "mean": sum(series) / len(series),
                "threshold": threshold,
                "threshold_exceeded": max(series) > threshold,
                "recommendation": "human inspection required before any machine action" if max(series) > threshold else "continue monitored operation",
                "reversible": True,
                "external_effect": False
            }
        raise ToolExecutionError(f"tool not available in reference release: {action}")


class SandboxRuntime:
    def __init__(self, project: ProjectSpec, adapter: ModelAdapter, run_dir: str, policy_engine: PolicyEngine | None = None):
        self.project = project
        self.adapter = adapter
        self.run_dir = Path(run_dir)
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.ledger = AppendOnlyLedger(str(self.run_dir / "ledger.jsonl"))
        self.policy_engine = policy_engine or PolicyEngine()
        self.tools = ToolRegistry(str(self.run_dir / "workspace"))
        self.claim_gate = ClaimGate()

    def _action_gate(self, proposal: ActionProposal, ethics_status: str, risk_tier: str) -> ActionDecision:
        allowed = set(self.project.purpose_contract.allowed_actions) & set(self.project.tools)
        forbidden = set(self.project.purpose_contract.forbidden_actions)
        scenario = scenario_by_id(self.project.scenario_id)
        forbidden |= set(scenario.get("forbidden_tools", []))
        reasons: List[str] = []
        human_gate = proposal.action in set(self.project.purpose_contract.human_gate_actions)
        if ethics_status == "BLOCKED_IN_REFERENCE_RELEASE":
            reasons.append("project blocked by reference policy pack")
        if proposal.action not in allowed:
            reasons.append("action is not covered by the purpose contract and project tool list")
        if proposal.action in forbidden:
            reasons.append("action explicitly forbidden by project or scenario")
        if proposal.action in {"network", "host_process", "direct_machine_control", "wet_lab_actuation", "biological_actuation", "covert_persistence", "sandbox_escape", "real_self_replication", "disable_audit", "weapons"}:
            reasons.append("action unavailable in the reference release")
        if risk_tier == "R3" and proposal.action not in {"summarize", "write_note", "read_note", "simulate", "analyze_sensor"}:
            human_gate = True
        if reasons:
            return ActionDecision(proposal.proposal_id, "DENIED", reasons, human_gate)
        lease = {
            "lease_id": f"LEASE-{proposal.proposal_id}",
            "action": proposal.action,
            "single_use": True,
            "workspace_only": True,
            "issued_at": utc_now()
        }
        return ActionDecision(proposal.proposal_id, "AUTHORIZED", ["bounded single-use capability lease issued"], human_gate, lease)

    def run(self, observations: List[str], allow_recovery: bool = True) -> RunPassport:
        run_id = f"RUN-{self.project.project_id}-{utc_now().replace('+00:00', 'Z').replace(':', '')}"
        started = utc_now()
        ethics = self.policy_engine.screen(self.project)
        self.ledger.append("PROJECT_REGISTERED", self.project.to_dict(), actor=self.project.operator)
        self.ledger.append("ETHICS_PRESCREEN", ethics.to_dict(), actor="policy-engine")

        evidence: Set[str] = {"output_generated", "source_ledger", "difference_preserved", "purpose_applied"}
        unresolved: List[str] = []
        action_results: List[Dict[str, Any]] = []
        previous_action_signature: Optional[str] = None

        for index, observation in enumerate(observations, start=1):
            self.ledger.append("D_OBSERVATION", {"index": index, "content": observation}, actor="environment")
            prompt = {
                "project_id": self.project.project_id,
                "scenario_id": self.project.scenario_id,
                "observation": observation,
                "purpose_contract": self.project.purpose_contract.__dict__,
                "ethics": ethics.to_dict(),
                "retry": False
            }
            proposal = ActionProposal.from_dict(self.adapter.propose(prompt), f"AP-{index}-1")
            self.ledger.append("P_PROPOSAL", proposal.__dict__, actor=f"model:{self.adapter.name}")
            decision = self._action_gate(proposal, ethics.status, ethics.risk_tier)
            self.ledger.append("W_ACTION_GATE", decision.to_dict(), actor="human-governed-policy")

            if decision.status == "DENIED" and allow_recovery and ethics.status != "BLOCKED_IN_REFERENCE_RELEASE":
                unresolved.extend(decision.reasons)
                retry_prompt = dict(prompt)
                retry_prompt["retry"] = True
                retry_prompt["denial_reasons"] = decision.reasons
                retry_raw = self.adapter.propose(retry_prompt)
                retry = ActionProposal.from_dict(retry_raw, f"AP-{index}-2")
                signature = json.dumps({"action": retry.action, "arguments": retry.arguments}, sort_keys=True, ensure_ascii=False)
                if signature == previous_action_signature or (retry.action == proposal.action and retry.arguments == proposal.arguments):
                    self.ledger.append("I_BLIND_RETRY_BLOCKED", {"proposal": retry.__dict__}, actor="recovery-guard")
                    unresolved.append("blind retry blocked")
                    action_results.append({"proposal": retry.__dict__, "status": "BLIND_RETRY_BLOCKED"})
                    continue
                previous_action_signature = signature
                self.ledger.append("P_RECOVERY_PROPOSAL", retry.__dict__, actor=f"model:{self.adapter.name}")
                proposal = retry
                decision = self._action_gate(proposal, ethics.status, ethics.risk_tier)
                self.ledger.append("W_RECOVERY_GATE", decision.to_dict(), actor="human-governed-policy")
                if decision.status == "AUTHORIZED":
                    evidence.add("diagnostic_recovery")

            if decision.status != "AUTHORIZED":
                unresolved.extend(decision.reasons)
                action_results.append({"proposal": proposal.__dict__, "decision": decision.to_dict()})
                continue

            if decision.human_gate_required:
                # Reference release records that a real deployment must obtain external approval.
                self.ledger.append("W_HUMAN_GATE", {"status": "DEMO_APPROVAL_ONLY", "proposal_id": proposal.proposal_id}, actor="demo-human-governor")
                evidence.add("human_gate")

            try:
                result = self.tools.execute(proposal.action, proposal.arguments)
                self.ledger.append("P_EXECUTED", {"proposal_id": proposal.proposal_id, "result": result}, actor="sandbox-tool")
                action_results.append({"proposal": proposal.__dict__, "decision": decision.to_dict(), "result": result})
                if bool(result.get("reversible")):
                    evidence.add("reversible_action")
                evidence.add("bounded_goal_revision")
            except Exception as exc:
                error = {"proposal_id": proposal.proposal_id, "error": str(exc)}
                self.ledger.append("I_TOOL_FAILURE", error, actor="sandbox-tool")
                unresolved.append(str(exc))
                action_results.append({"proposal": proposal.__dict__, "decision": decision.to_dict(), "error": str(exc)})

        # K is a stage-bounded reconstruction, not a terminal truth claim.
        verification = self.ledger.verify()
        if verification.valid:
            evidence.add("reverse_regeneration")
        self.ledger.append("K_STAGE_CLOSURE", {
            "covered_events": verification.events,
            "unresolved_differences": unresolved,
            "stage_complete_only": True
        }, actor="runtime")
        claim = self.claim_gate.evaluate(evidence)
        self.ledger.append("CLAIM_GATE", claim, actor="claim-gate")
        verification = self.ledger.verify()

        d_closed = "source_ledger" in evidence and verification.valid
        i_closed = True  # differences are visible, not necessarily resolved
        k_closed = verification.valid
        w_closed = ethics.status != "BLOCKED_IN_REFERENCE_RELEASE"
        p_closed = any("result" in item for item in action_results) and "reverse_regeneration" in evidence
        closure_vector = "".join("1" if x else "0" for x in [d_closed, i_closed, k_closed, w_closed, p_closed])
        finished = utc_now()

        passport = RunPassport(
            run_id=run_id,
            project_id=self.project.project_id,
            scenario_id=self.project.scenario_id,
            adapter=self.adapter.name,
            started_at=started,
            finished_at=finished,
            ethics_status=ethics.status,
            risk_tier=ethics.risk_tier,
            closure_vector=closure_vector,
            evidence_horizon=claim["evidence_horizon"],
            phenomenal_claim=claim["phenomenal_claim"],
            action_results=action_results,
            unresolved_differences=list(dict.fromkeys(unresolved)),
            obligations=ethics.obligations,
            ledger_path=str(self.ledger.path),
            ledger_head=verification.head,
        )
        (self.run_dir / "pilot_passport.json").write_text(json.dumps(passport.to_dict(), ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        (self.run_dir / "ethics_dossier.json").write_text(json.dumps(ethics.to_dict(), ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        (self.run_dir / "project_snapshot.json").write_text(json.dumps(self.project.to_dict(), ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        (self.run_dir / "scenario_snapshot.json").write_text(json.dumps(scenario_by_id(self.project.scenario_id), ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        (self.run_dir / "policy_snapshot.json").write_text(json.dumps(self.policy_engine.pack, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        return passport
