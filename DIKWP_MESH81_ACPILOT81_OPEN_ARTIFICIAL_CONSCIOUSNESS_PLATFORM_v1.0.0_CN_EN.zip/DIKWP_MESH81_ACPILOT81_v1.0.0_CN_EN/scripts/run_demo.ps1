$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$env:PYTHONPATH = Join-Path $Root "src"
python -m acpilot81 run (Join-Path $Root "examples\projects\industrial_maintenance.json") --out (Join-Path $Root "examples\outputs\industrial_demo") --observation "Synthetic temperature series rises from 72 to 88; threshold 85."
