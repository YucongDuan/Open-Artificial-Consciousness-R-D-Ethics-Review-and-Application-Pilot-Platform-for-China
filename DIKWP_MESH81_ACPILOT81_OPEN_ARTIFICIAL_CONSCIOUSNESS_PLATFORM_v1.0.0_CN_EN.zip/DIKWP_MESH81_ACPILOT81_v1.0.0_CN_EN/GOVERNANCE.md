# Open Governance

AC-PILOT81 separates four authorities:

1. **Research authority** proposes variables, interventions, evidence horizons, and scenarios.
2. **Engineering authority** maintains adapters, schemas, tests, and reproducible builds.
3. **Ethics and policy authority** reviews policy packs, human-impact obligations, and claim boundaries.
4. **Application authority** owns the real use case, data, affected persons, incident response, and deployment decision.

No single model, author, vendor, evaluator, or sponsor may both define a consciousness claim and certify it unilaterally.

Policy-pack updates must be versioned, sourced, reviewed, and must not silently change past dossiers. New evidence is appended; previous conclusions remain reproducible under their original version.
