"""AC-PILOT81: open R&D, ethics review, and application pilot infrastructure."""

__version__ = "1.0.0"
SYSTEM_ID = "DIKWP-MESH8.1-AC-PILOT81"
MODE = "MESH81_DIKWP_NATIVE_CONTINUITY"
