from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Set

from .policy import load_json_resource


class ClaimGate:
    def __init__(self, taxonomy: Mapping[str, Any] | None = None):
        self.taxonomy = dict(taxonomy or load_json_resource("claim_horizons.json"))

    def evaluate(self, evidence: Iterable[str]) -> Dict[str, Any]:
        flags: Set[str] = set(evidence)
        achieved = "H0"
        missing_by_horizon: Dict[str, List[str]] = {}
        for horizon in self.taxonomy.get("horizons", []):
            required = list(horizon.get("minimum", []))
            missing = [item for item in required if item not in flags]
            missing_by_horizon[horizon["id"]] = missing
            if not missing:
                achieved = horizon["id"]
            else:
                break
        return {
            "evidence_horizon": achieved,
            "phenomenal_claim": "UNRESOLVED_AND_NOT_CERTIFIED",
            "missing_by_horizon": missing_by_horizon,
            "prohibited_claims": self.taxonomy.get("prohibited_claims", []),
            "note": "Operational evidence horizon only. It does not prove phenomenal consciousness, sentience, legal personhood, or human equivalence."
        }
