#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PYTHONPATH="$ROOT/src" python -m acpilot81 serve --host 127.0.0.1 --port 8181 --workspace "$ROOT/examples/outputs/server_workspace"
