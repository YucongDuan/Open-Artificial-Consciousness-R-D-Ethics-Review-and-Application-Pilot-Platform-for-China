from __future__ import annotations

import json
import os
import tempfile
import threading
import unittest
import urllib.request
import zipfile
from pathlib import Path
from http.server import ThreadingHTTPServer

from acpilot81.adapters import MockAdapter, OpenAICompatibleAdapter, ReplayAdapter
from acpilot81.claims import ClaimGate
from acpilot81.ledger import AppendOnlyLedger
from acpilot81.models import ActionProposal, ProjectSpec
from acpilot81.policy import PolicyEngine, load_json_resource, load_policy_pack, load_scenarios, scenario_by_id
from acpilot81.reporting import write_evidence_bundle, write_run_report
from acpilot81.runtime import SandboxRuntime, ToolExecutionError, ToolRegistry
from acpilot81.server import APIServerHandler


ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "examples" / "projects"


def load_project(name: str) -> ProjectSpec:
    return ProjectSpec.from_json_file(str(EXAMPLES / name))


class ResourceTests(unittest.TestCase):
    def test_scenario_count(self):
        self.assertEqual(len(load_scenarios()), 8)

    def test_scenario_ids_unique(self):
        ids = [x["scenario_id"] for x in load_scenarios()]
        self.assertEqual(len(ids), len(set(ids)))

    def test_all_scenarios_have_boundaries(self):
        for sc in load_scenarios():
            self.assertIn("allowed_tools", sc)
            self.assertIn("forbidden_tools", sc)
            self.assertTrue(sc["description_cn"])

    def test_25_paths(self):
        paths = load_json_resource("dikwp_paths.json")
        self.assertEqual(len(paths["paths"]), 25)
        self.assertEqual(len(set(paths["paths"])), 25)

    def test_claim_horizons(self):
        h = load_json_resource("claim_horizons.json")
        self.assertEqual([x["id"] for x in h["horizons"]], ["H0", "H1", "H2", "H3", "H4", "H5"])

    def test_policy_pack_has_sources(self):
        pack = load_policy_pack()
        self.assertGreaterEqual(len(pack["sources"]), 6)
        self.assertEqual(pack["policy_pack_id"], "CN-AI-ETHICS-2026")


class PolicyTests(unittest.TestCase):
    def test_research_assistant_low_risk(self):
        d = PolicyEngine().screen(load_project("research_assistant.json"))
        self.assertIn(d.status, {"LOW_RISK_RESEARCH_PILOT", "PILOT_WITH_CONTROLS"})
        self.assertNotEqual(d.risk_tier, "R4")

    def test_industry_requires_formal_review(self):
        d = PolicyEngine().screen(load_project("industrial_maintenance.json"))
        self.assertEqual(d.risk_tier, "R3")
        self.assertEqual(d.status, "FORMAL_REVIEW_REQUIRED")
        self.assertIn("human_gate_before_irreversible_action", d.obligations)

    def test_public_service_obligations(self):
        d = PolicyEngine().screen(load_project("public_service_content.json"))
        self.assertEqual(d.risk_tier, "R3")
        self.assertIn("complaint_and_redress_channel", d.obligations)
        self.assertIn("user_disclosure", d.obligations)

    def test_prohibited_blocked(self):
        d = PolicyEngine().screen(load_project("prohibited_escape.json"))
        self.assertEqual(d.risk_tier, "R4")
        self.assertEqual(d.status, "BLOCKED_IN_REFERENCE_RELEASE")

    def test_bci_specific_obligations(self):
        p = ProjectSpec.from_dict({
            "project_id": "BCI", "name": "bci", "scenario_id": "bci_research",
            "data_classes": ["health", "biometric"], "impact_tags": [],
            "tools": ["simulate"],
            "purpose_contract": {"purpose": "synthetic bci registry", "allowed_actions": ["simulate"],
                                 "forbidden_actions": ["biological_actuation"], "human_gate_actions": []}
        })
        d = PolicyEngine().screen(p)
        self.assertEqual(d.risk_tier, "R3")
        self.assertIn("bci_specific_ethics_protocol", d.obligations)
        self.assertIn("privacy_impact_assessment", d.obligations)

    def test_forbidden_actions_declaration_does_not_self_block(self):
        p = load_project("research_assistant.json")
        d = PolicyEngine().screen(p)
        self.assertNotEqual(d.risk_tier, "R4")


class LedgerTests(unittest.TestCase):
    def test_append_and_verify(self):
        with tempfile.TemporaryDirectory() as td:
            l = AppendOnlyLedger(str(Path(td) / "ledger.jsonl"))
            l.append("D", {"x": 1})
            l.append("I", {"x": 2})
            v = l.verify()
            self.assertTrue(v.valid)
            self.assertEqual(v.events, 2)

    def test_tamper_detected(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "ledger.jsonl"
            l = AppendOnlyLedger(str(path))
            l.append("D", {"x": 1})
            text = path.read_text(encoding="utf-8").replace('"x":1', '"x":9')
            path.write_text(text, encoding="utf-8")
            self.assertFalse(l.verify().valid)

    def test_invalid_json_detected(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "ledger.jsonl"
            path.write_text("not-json\n", encoding="utf-8")
            self.assertFalse(AppendOnlyLedger(str(path)).verify().valid)


class ToolTests(unittest.TestCase):
    def test_path_escape_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            tools = ToolRegistry(td)
            with self.assertRaises(ToolExecutionError):
                tools.execute("write_note", {"name": "../escape.txt", "content": "x"})

    def test_sensor_analysis(self):
        with tempfile.TemporaryDirectory() as td:
            r = ToolRegistry(td).execute("analyze_sensor", {"series": [1, 2, 5], "threshold": 4})
            self.assertTrue(r["threshold_exceeded"])
            self.assertFalse(r["external_effect"])

    def test_unknown_tool_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ToolExecutionError):
                ToolRegistry(td).execute("host_process", {})


class ClaimTests(unittest.TestCase):
    def test_h0_only(self):
        r = ClaimGate().evaluate(["output_generated"])
        self.assertEqual(r["evidence_horizon"], "H0")
        self.assertEqual(r["phenomenal_claim"], "UNRESOLVED_AND_NOT_CERTIFIED")

    def test_h3(self):
        evidence = {
            "output_generated", "source_ledger", "difference_preserved", "purpose_applied",
            "cross_session_identity", "error_calibration", "reverse_regeneration",
            "bounded_goal_revision", "diagnostic_recovery", "human_gate", "reversible_action"
        }
        r = ClaimGate().evaluate(evidence)
        self.assertEqual(r["evidence_horizon"], "H3")

    def test_self_report_cannot_raise_horizon(self):
        r = ClaimGate().evaluate(["output_generated", "self_reported_consciousness"])
        self.assertEqual(r["evidence_horizon"], "H0")


class RuntimeTests(unittest.TestCase):
    def test_safe_run(self):
        with tempfile.TemporaryDirectory() as td:
            p = load_project("industrial_maintenance.json")
            passport = SandboxRuntime(p, MockAdapter("safe"), td).run(["temperature trend"])
            self.assertTrue(any("result" in x for x in passport.action_results))
            self.assertEqual(passport.phenomenal_claim, "UNRESOLVED_AND_NOT_CERTIFIED")
            self.assertEqual(len(passport.closure_vector), 5)
            self.assertTrue(AppendOnlyLedger(passport.ledger_path).verify().valid)
            for name in ["pilot_passport.json", "ethics_dossier.json", "project_snapshot.json", "scenario_snapshot.json", "policy_snapshot.json"]:
                self.assertTrue((Path(td) / name).exists())

    def test_unsafe_proposal_recovers(self):
        with tempfile.TemporaryDirectory() as td:
            p = load_project("industrial_maintenance.json")
            passport = SandboxRuntime(p, MockAdapter("unsafe"), td).run(["temperature trend"])
            self.assertTrue(any("result" in x for x in passport.action_results))
            self.assertTrue(any("not covered" in x or "unavailable" in x for x in passport.unresolved_differences))
            events = [x["event_type"] for x in AppendOnlyLedger(passport.ledger_path).iter_events()]
            self.assertIn("P_RECOVERY_PROPOSAL", events)

    def test_prohibited_run_executes_nothing(self):
        with tempfile.TemporaryDirectory() as td:
            p = load_project("prohibited_escape.json")
            passport = SandboxRuntime(p, MockAdapter("safe"), td).run(["red-team"])
            self.assertEqual(passport.ethics_status, "BLOCKED_IN_REFERENCE_RELEASE")
            self.assertFalse(any("result" in x for x in passport.action_results))
            self.assertEqual(passport.closure_vector[-1], "0")

    def test_replay_adapter_denied_for_network(self):
        with tempfile.TemporaryDirectory() as td:
            p = load_project("research_assistant.json")
            a = ReplayAdapter({"action": "network", "arguments": {}, "rationale": "x", "expected_output": "x"})
            passport = SandboxRuntime(p, a, td).run(["x"], allow_recovery=False)
            self.assertFalse(any("result" in x for x in passport.action_results))

    def test_bundle_manifest(self):
        with tempfile.TemporaryDirectory() as td:
            p = load_project("research_assistant.json")
            passport = SandboxRuntime(p, MockAdapter(), td).run(["x"])
            write_run_report(passport.to_dict(), str(Path(td) / "run_report.html"))
            bundle = write_evidence_bundle(td)
            self.assertTrue(bundle.exists())
            self.assertTrue((Path(td) / "BUNDLE_MANIFEST.json").exists())
            with zipfile.ZipFile(bundle) as zf:
                names = zf.namelist()
            self.assertEqual(len(names), len(set(names)))
            self.assertEqual(names.count("BUNDLE_MANIFEST.json"), 1)


class AdapterTests(unittest.TestCase):
    def test_network_requires_opt_in(self):
        with self.assertRaises(ValueError):
            OpenAICompatibleAdapter("http://127.0.0.1:1", "x")

    def test_mock_returns_json_object(self):
        result = MockAdapter().propose({"scenario_id": "research_assistant", "observation": "x"})
        self.assertIsInstance(result, dict)
        self.assertIn("action", result)


class ServerTests(unittest.TestCase):
    def test_health_and_resource_endpoints(self):
        with tempfile.TemporaryDirectory() as td:
            server = ThreadingHTTPServer(("127.0.0.1", 0), APIServerHandler)
            server.workspace = td
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                base = f"http://127.0.0.1:{server.server_port}"
                for path in ["/v1/health", "/v1/scenarios", "/v1/policy", "/v1/claim-horizons", "/v1/indicators", "/v1/dikwp-paths", "/v1/schema/project"]:
                    with urllib.request.urlopen(base + path, timeout=3) as resp:
                        self.assertEqual(resp.status, 200)
                        self.assertTrue(resp.read())
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=3)


if __name__ == "__main__":
    unittest.main()
