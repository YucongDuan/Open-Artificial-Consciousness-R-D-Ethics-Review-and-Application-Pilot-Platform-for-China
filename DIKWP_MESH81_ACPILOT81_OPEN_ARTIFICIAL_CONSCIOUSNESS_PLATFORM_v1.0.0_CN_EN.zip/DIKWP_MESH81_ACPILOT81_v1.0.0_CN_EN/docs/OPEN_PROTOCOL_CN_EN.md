# AC-PILOT Open Pilot Protocol 0.1 / 人工意识开放中试协议 0.1

## Required objects / 必需对象

1. Project Card / 项目卡
2. Purpose Contract / 目的合同
3. Scenario and model snapshot / 场景与模型快照
4. Ethics pre-screen and review record / 伦理预审与复核记录
5. D/I/K/W/P append-only ledger / 五元追加式账本
6. Intervention contract / 干预合同
7. Stop, recovery and rollback plan / 停止、恢复与回滚计划
8. Pilot passport / 中试护照
9. Unresolved-difference register / 未闭合差异清单
10. Claim boundary / 声明边界

## Invariants / 不可静默改变项

- Source and version identity / 来源与版本身份
- Unresolved differences / 未解决差异
- Human accountability / 人类责任
- Applicable policy and value context / 适用政策与价值语境
- Action authorization and result / 动作授权与结果
- Claim horizon and prohibited claims / 证据地平线与禁止声明

## Settlement / 结算

A pilot may be structurally complete while the phenomenal-consciousness question remains unresolved. `11111` means the five declared evidence positions are present under the current project and policy version. It does not mean consciousness is proven.
