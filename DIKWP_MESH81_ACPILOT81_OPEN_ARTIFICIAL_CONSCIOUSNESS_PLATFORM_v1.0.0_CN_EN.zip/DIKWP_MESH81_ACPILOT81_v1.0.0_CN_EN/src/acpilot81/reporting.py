from __future__ import annotations

import hashlib
import html
import json
import zipfile
from pathlib import Path
from typing import Any, Mapping


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_run_report(passport: Mapping[str, Any], output_path: str) -> None:
    p = Path(output_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for key in [
        "run_id", "project_id", "scenario_id", "adapter", "ethics_status",
        "risk_tier", "closure_vector", "evidence_horizon", "phenomenal_claim", "ledger_head"
    ]:
        rows.append(f"<tr><th>{html.escape(key)}</th><td>{html.escape(str(passport.get(key, '')))}</td></tr>")
    unresolved = "".join(f"<li>{html.escape(str(x))}</li>" for x in passport.get("unresolved_differences", [])) or "<li>None recorded</li>"
    obligations = "".join(f"<li>{html.escape(str(x))}</li>" for x in passport.get("obligations", []))
    actions = html.escape(json.dumps(passport.get("action_results", []), ensure_ascii=False, indent=2))
    doc = f"""<!doctype html>
<html lang='zh-CN'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>AC-PILOT81 Run Report</title>
<style>body{{font-family:system-ui,'Noto Sans CJK SC',sans-serif;background:#f5f7fb;color:#172033;margin:0}}main{{max-width:1050px;margin:32px auto;background:white;padding:34px;border-radius:18px;box-shadow:0 8px 40px #1b315022}}h1{{margin-top:0}}table{{width:100%;border-collapse:collapse}}th,td{{border-bottom:1px solid #dde3ed;padding:10px;text-align:left;vertical-align:top}}th{{width:220px;color:#38527a}}pre{{white-space:pre-wrap;background:#0f172a;color:#e2e8f0;padding:18px;border-radius:12px}}.notice{{background:#fff7d6;border-left:5px solid #d9a300;padding:14px}}footer{{color:#6b7280;margin-top:30px}}</style></head>
<body><main><h1>AC-PILOT81 Pilot Passport</h1><p class='notice'>Operational research evidence only. This report does not certify phenomenal consciousness, sentience, legal personhood, regulatory compliance, ethics approval, or production fitness.</p><table>{''.join(rows)}</table><h2>Unresolved differences</h2><ul>{unresolved}</ul><h2>Obligations</h2><ul>{obligations}</ul><h2>Action results</h2><pre>{actions}</pre><footer>DIKWP-MESH8.1 AC-PILOT81 reference release</footer></main></body></html>"""
    p.write_text(doc, encoding="utf-8")


def write_evidence_bundle(run_dir: str, bundle_path: str | None = None) -> Path:
    """Create a portable dossier with a deterministic file manifest.

    The manifest records file digests. It is not a regulator-issued certificate or trusted timestamp.
    """
    root = Path(run_dir).resolve()
    if bundle_path is None:
        bundle = root / "acpilot81_evidence_bundle.zip"
    else:
        bundle = Path(bundle_path).resolve()
    bundle.parent.mkdir(parents=True, exist_ok=True)

    manifest_path = root / "BUNDLE_MANIFEST.json"
    candidates = [
        p for p in sorted(root.rglob("*"))
        if p.is_file()
        and p.resolve() not in {bundle, manifest_path}
        and "__pycache__" not in p.parts
    ]
    manifest = {
        "schema": "acpilot81.evidence-bundle/1.0",
        "system": "DIKWP-MESH8.1-AC-PILOT81",
        "boundary": "Structural research dossier only; no phenomenal-consciousness, legal, clinical, ethics-committee or regulatory certification.",
        "files": [
            {"path": str(p.relative_to(root)).replace("\\", "/"), "size": p.stat().st_size, "sha256": _sha256(p)}
            for p in candidates
        ]
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    candidates.append(manifest_path)

    with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(candidates):
            zf.write(p, arcname=str(p.relative_to(root)).replace("\\", "/"))
    return bundle
