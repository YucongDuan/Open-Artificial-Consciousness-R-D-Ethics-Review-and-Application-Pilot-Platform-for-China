# Contributing

Contributions are welcome in six tracks: scenarios, model adapters, policy packs, evidence protocols, test infrastructure, and application pilots.

A contribution must:

- preserve the no-phenomenal-certification boundary;
- declare data and model provenance;
- include tests;
- preserve unresolved differences rather than deleting them;
- avoid real self-replication, covert persistence, escape, weapons, biological actuation, or unauthorized high-impact actions;
- state whether it changes a D, I, K, W, or P record and which explicit paths it adds.

Run `scripts/run_tests.sh` before submitting.
