#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PYTHONPATH="$ROOT/src" python -m acpilot81 run "$ROOT/examples/projects/industrial_maintenance.json" \
  --out "$ROOT/examples/outputs/industrial_demo" \
  --observation "Synthetic temperature series rises from 72 to 88; threshold 85."
echo "Open: $ROOT/examples/outputs/industrial_demo/run_report.html"
