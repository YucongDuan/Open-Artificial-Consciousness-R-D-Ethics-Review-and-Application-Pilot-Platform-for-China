# Security Policy

## Reference-release guarantees

- Network is disabled unless an operator explicitly selects the OpenAI-compatible adapter and passes `--allow-network`.
- Tool execution is allow-listed and confined to a run workspace.
- File path traversal is blocked.
- Real self-replication, covert persistence, sandbox escape, host-process control, audit disabling, weapons, biological actuation, and direct machine control are unavailable.
- Every project declares a Purpose contract and every action passes a separate gate.

## Reporting

Do not include personal data, model credentials, private datasets, or exploitable details in public reports. Report vulnerabilities privately to the project maintainer before public disclosure.

## Non-goals

The hash-chain ledger is an integrity aid, not a qualified electronic signature, trusted timestamp, HSM-backed audit trail, or tamper-proof hardware root. Production deployments require independent security engineering.
