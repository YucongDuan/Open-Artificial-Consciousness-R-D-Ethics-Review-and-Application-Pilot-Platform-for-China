# Architecture / 系统架构

```text
Project + Purpose Contract
            |
            v
China Policy & Ethics Reference Pack
            |
            v
D/I/K/W/P Append-only Evidence Ledger
            |
            v
Replaceable Model Proposal Adapter
            |
            v
W Action Gate + Single-use Capability Lease
            |
            v
Local Reversible Sandbox Tools
            |
            v
Pilot Passport + Ethics Dossier + Evidence Bundle
```

The model never owns tool authority. Policy versions never silently rewrite past runs. Failed actions and unresolved differences remain in I. K is explicitly stage-bounded. The phenomenal-consciousness question remains unresolved at every operational evidence horizon.

模型不拥有工具执行权；政策版本不能静默改写历史运行；失败动作与未解决差异保留在 I；K 只表示阶段性覆盖；所有操作性地平线都不解决现象意识问题。
