from __future__ import annotations

import argparse
import json
import os
import tempfile
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources
from pathlib import Path
from typing import Any, Dict

from .adapters import MockAdapter
from .models import ProjectSpec
from .policy import PolicyEngine, load_json_resource, load_policy_pack, load_scenarios
from .runtime import SandboxRuntime


class APIServerHandler(BaseHTTPRequestHandler):
    server_version = "AC-PILOT81/1.0"

    def _json(self, data: Any, status: int = 200) -> None:
        raw = json.dumps(data, ensure_ascii=False, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(raw)

    def _read_json(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8")) if raw else {}

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.end_headers()

    def do_GET(self) -> None:
        if self.path in {"/", "/index.html"}:
            target = resources.files("acpilot81").joinpath("resources/dashboard.html")
            content = target.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
            return
        if self.path == "/v1/health":
            self._json({"status": "ok", "system": "DIKWP-MESH8.1-AC-PILOT81", "version": "1.0.0"})
            return
        if self.path == "/v1/scenarios":
            self._json(load_scenarios())
            return
        if self.path == "/v1/policy":
            self._json(load_policy_pack())
            return
        if self.path == "/v1/claim-horizons":
            self._json(load_json_resource("claim_horizons.json"))
            return
        if self.path == "/v1/indicators":
            self._json(load_json_resource("indicator_catalog.json"))
            return
        if self.path == "/v1/dikwp-paths":
            self._json(load_json_resource("dikwp_paths.json"))
            return
        if self.path == "/v1/schema/project":
            self._json(load_json_resource("schemas/project.schema.json"))
            return
        self._json({"error": "not found"}, 404)

    def do_POST(self) -> None:
        try:
            payload = self._read_json()
            project_raw = payload.get("project", payload)
            project = ProjectSpec.from_dict(project_raw)
            if self.path == "/v1/screen":
                self._json(PolicyEngine().screen(project).to_dict())
                return
            if self.path == "/v1/demo-run":
                observations = list(payload.get("observations", ["Synthetic observation for local demonstration."]))
                run_root = Path(getattr(self.server, "workspace")) / project.project_id
                runtime = SandboxRuntime(project, MockAdapter(str(payload.get("mock_mode", "safe"))), str(run_root))
                passport = runtime.run(observations)
                self._json(passport.to_dict())
                return
            self._json({"error": "not found"}, 404)
        except Exception as exc:
            self._json({"error": str(exc)}, 400)

    def log_message(self, fmt: str, *args: Any) -> None:
        # Keep local demos quiet by default.
        return


def serve(host: str = "127.0.0.1", port: int = 8181, workspace: str = "./acpilot81_workspace") -> None:
    server = ThreadingHTTPServer((host, port), APIServerHandler)
    server.workspace = os.path.abspath(workspace)  # type: ignore[attr-defined]
    os.makedirs(server.workspace, exist_ok=True)  # type: ignore[arg-type]
    print(f"AC-PILOT81 listening on http://{host}:{port}")
    print(f"Workspace: {server.workspace}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
