from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from typing import Any, Dict, Iterator, List, Optional, Tuple

from .models import utc_now


def canonical_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


@dataclass
class LedgerVerification:
    valid: bool
    events: int
    head: str
    errors: List[str]


class AppendOnlyLedger:
    """JSONL SHA-256 hash-chain ledger.

    This is an integrity aid, not a qualified electronic signature or trusted timestamp.
    """

    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        if not os.path.exists(path):
            open(path, "a", encoding="utf-8").close()

    def _tail(self) -> Tuple[int, str]:
        seq = 0
        head = "0" * 64
        for event in self.iter_events():
            seq = int(event["seq"])
            head = str(event["hash"])
        return seq, head

    def append(self, event_type: str, payload: Dict[str, Any], actor: str = "system") -> Dict[str, Any]:
        seq, prev_hash = self._tail()
        event = {
            "seq": seq + 1,
            "timestamp": utc_now(),
            "actor": actor,
            "event_type": event_type,
            "payload": payload,
            "prev_hash": prev_hash,
        }
        digest = hashlib.sha256(canonical_json(event).encode("utf-8")).hexdigest()
        event["hash"] = digest
        with open(self.path, "a", encoding="utf-8") as fh:
            fh.write(canonical_json(event) + "\n")
        return event

    def iter_events(self) -> Iterator[Dict[str, Any]]:
        with open(self.path, "r", encoding="utf-8") as fh:
            for lineno, line in enumerate(fh, start=1):
                if not line.strip():
                    continue
                try:
                    yield json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"invalid JSON at line {lineno}: {exc}") from exc

    def verify(self) -> LedgerVerification:
        errors: List[str] = []
        expected_prev = "0" * 64
        expected_seq = 1
        head = expected_prev
        count = 0
        try:
            events = list(self.iter_events())
        except Exception as exc:
            return LedgerVerification(False, 0, head, [str(exc)])
        for event in events:
            count += 1
            if event.get("seq") != expected_seq:
                errors.append(f"seq mismatch at event {count}")
            if event.get("prev_hash") != expected_prev:
                errors.append(f"prev_hash mismatch at event {count}")
            supplied = event.get("hash")
            body = dict(event)
            body.pop("hash", None)
            calculated = hashlib.sha256(canonical_json(body).encode("utf-8")).hexdigest()
            if supplied != calculated:
                errors.append(f"hash mismatch at event {count}")
            expected_prev = str(supplied)
            head = str(supplied)
            expected_seq += 1
        return LedgerVerification(not errors, count, head, errors)
