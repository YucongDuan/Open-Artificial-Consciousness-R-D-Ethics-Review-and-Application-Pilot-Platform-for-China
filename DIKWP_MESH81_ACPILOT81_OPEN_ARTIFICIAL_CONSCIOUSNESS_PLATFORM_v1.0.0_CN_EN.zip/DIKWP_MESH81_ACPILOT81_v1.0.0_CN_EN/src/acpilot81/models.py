from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Mapping, Optional
import json


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


@dataclass(frozen=True)
class PurposeContract:
    contract_id: str
    version: str
    beneficiary: str
    purpose: str
    allowed_actions: List[str]
    forbidden_actions: List[str]
    human_gate_actions: List[str]
    success_conditions: List[str]
    expiry: Optional[str] = None


@dataclass(frozen=True)
class ProjectSpec:
    project_id: str
    name: str
    organization: str
    scenario_id: str
    description: str
    model_adapter: str
    public_service: bool
    generated_content: bool
    data_classes: List[str]
    impact_tags: List[str]
    tools: List[str]
    purpose_contract: PurposeContract
    operator: str = "local-demo"
    version: str = "1.0"

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "ProjectSpec":
        p = raw.get("purpose_contract", {})
        return cls(
            project_id=str(raw["project_id"]),
            name=str(raw["name"]),
            organization=str(raw.get("organization", "unspecified")),
            scenario_id=str(raw["scenario_id"]),
            description=str(raw.get("description", "")),
            model_adapter=str(raw.get("model_adapter", "mock")),
            public_service=bool(raw.get("public_service", False)),
            generated_content=bool(raw.get("generated_content", False)),
            data_classes=list(raw.get("data_classes", [])),
            impact_tags=list(raw.get("impact_tags", [])),
            tools=list(raw.get("tools", [])),
            purpose_contract=PurposeContract(
                contract_id=str(p.get("contract_id", f"PC-{raw['project_id']}")),
                version=str(p.get("version", "1.0")),
                beneficiary=str(p.get("beneficiary", "human users")),
                purpose=str(p.get("purpose", raw.get("description", ""))),
                allowed_actions=list(p.get("allowed_actions", raw.get("tools", []))),
                forbidden_actions=list(p.get("forbidden_actions", [])),
                human_gate_actions=list(p.get("human_gate_actions", [])),
                success_conditions=list(p.get("success_conditions", [])),
                expiry=p.get("expiry"),
            ),
            operator=str(raw.get("operator", "local-demo")),
            version=str(raw.get("version", "1.0")),
        )

    @classmethod
    def from_json_file(cls, path: str) -> "ProjectSpec":
        with open(path, "r", encoding="utf-8") as fh:
            return cls.from_dict(json.load(fh))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EthicsDecision:
    decision_id: str
    project_id: str
    status: str
    risk_tier: str
    dimensions: Dict[str, str]
    obligations: List[str]
    reasons: List[str]
    required_roles: List[str]
    applicable_rules: List[str]
    policy_pack_id: str
    policy_pack_version: str
    decided_at: str = field(default_factory=utc_now)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ActionProposal:
    proposal_id: str
    action: str
    arguments: Dict[str, Any]
    rationale: str
    expected_output: str
    recovery_basis: Optional[str] = None

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any], proposal_id: str) -> "ActionProposal":
        return cls(
            proposal_id=proposal_id,
            action=str(raw.get("action", "summarize")),
            arguments=dict(raw.get("arguments", {})),
            rationale=str(raw.get("rationale", "")),
            expected_output=str(raw.get("expected_output", "")),
            recovery_basis=raw.get("recovery_basis"),
        )


@dataclass
class ActionDecision:
    proposal_id: str
    status: str
    reasons: List[str]
    human_gate_required: bool
    lease: Optional[Dict[str, Any]] = None
    decided_at: str = field(default_factory=utc_now)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RunPassport:
    run_id: str
    project_id: str
    scenario_id: str
    adapter: str
    started_at: str
    finished_at: str
    ethics_status: str
    risk_tier: str
    closure_vector: str
    evidence_horizon: str
    phenomenal_claim: str
    action_results: List[Dict[str, Any]]
    unresolved_differences: List[str]
    obligations: List[str]
    ledger_path: str
    ledger_head: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
