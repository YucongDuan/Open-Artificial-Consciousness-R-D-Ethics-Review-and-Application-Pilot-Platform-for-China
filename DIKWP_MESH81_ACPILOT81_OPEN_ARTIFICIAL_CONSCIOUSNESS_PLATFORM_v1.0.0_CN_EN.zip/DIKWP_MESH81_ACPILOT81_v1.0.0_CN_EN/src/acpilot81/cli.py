from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

from . import MODE, SYSTEM_ID, __version__
from .adapters import MockAdapter, OpenAICompatibleAdapter
from .ledger import AppendOnlyLedger
from .models import ProjectSpec
from .policy import PolicyEngine, load_json_resource, load_policy_pack, load_scenarios
from .reporting import write_evidence_bundle, write_run_report
from .runtime import SandboxRuntime
from .server import serve


def dump(data: object) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))


def cmd_summary(_: argparse.Namespace) -> int:
    scenarios = load_scenarios()
    dump({
        "system": SYSTEM_ID,
        "version": __version__,
        "mode": MODE,
        "scenario_count": len(scenarios),
        "policy_pack": load_policy_pack()["policy_pack_id"],
        "core_semantics": ["D", "I", "K", "W", "P"],
        "directed_paths": 25,
        "phenomenal_consciousness_certification": False,
        "reference_release_network_default": "off"
    })
    return 0



def cmd_policy(_: argparse.Namespace) -> int:
    dump(load_policy_pack())
    return 0


def cmd_claim_horizons(_: argparse.Namespace) -> int:
    dump(load_json_resource("claim_horizons.json"))
    return 0


def cmd_init_project(args: argparse.Namespace) -> int:
    scenarios = {x["scenario_id"]: x for x in load_scenarios()}
    if args.scenario not in scenarios:
        raise ValueError(f"unknown scenario: {args.scenario}")
    sc = scenarios[args.scenario]
    allowed = list(sc.get("allowed_tools", []))
    raw = {
        "project_id": args.project_id,
        "name": args.name or sc.get("name_cn", args.scenario),
        "organization": args.organization,
        "scenario_id": args.scenario,
        "description": sc.get("description_cn", ""),
        "model_adapter": "mock",
        "public_service": args.scenario == "public_service_content",
        "generated_content": args.scenario in {"research_assistant", "public_service_content", "adult_learning_companion"},
        "data_classes": ["sensitive_personal_data"] if args.scenario in {"organization_memory", "bci_research"} else [],
        "impact_tags": list(sc.get("impact_tags", [])),
        "tools": allowed,
        "purpose_contract": {
            "contract_id": f"PC-{args.project_id}",
            "version": "1.0",
            "beneficiary": "human stakeholders",
            "purpose": sc.get("description_cn", ""),
            "allowed_actions": allowed,
            "forbidden_actions": list(sc.get("forbidden_tools", [])),
            "human_gate_actions": ["external_publish", "direct_machine_control", "biological_actuation"],
            "success_conditions": ["ledger verifies", "differences preserved", "human accountability retained"]
        }
    }
    target = Path(args.output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    dump({"written": str(target), "project": raw})
    return 0

def cmd_scenarios(_: argparse.Namespace) -> int:
    dump(load_scenarios())
    return 0


def cmd_screen(args: argparse.Namespace) -> int:
    project = ProjectSpec.from_json_file(args.project)
    decision = PolicyEngine().screen(project)
    dump(decision.to_dict())
    return 0 if decision.status != "BLOCKED_IN_REFERENCE_RELEASE" else 2


def _adapter_from_args(args: argparse.Namespace):
    if args.adapter == "mock":
        return MockAdapter(args.mock_mode)
    if args.adapter == "openai-compatible":
        return OpenAICompatibleAdapter(args.endpoint, args.model, args.api_key, allow_network=args.allow_network)
    raise ValueError(f"unsupported adapter: {args.adapter}")


def cmd_run(args: argparse.Namespace) -> int:
    project = ProjectSpec.from_json_file(args.project)
    out = os.path.abspath(args.out)
    os.makedirs(out, exist_ok=True)
    adapter = _adapter_from_args(args)
    runtime = SandboxRuntime(project, adapter, out)
    observations = args.observation or ["Synthetic local observation."]
    passport = runtime.run(observations, allow_recovery=not args.no_recovery)
    write_run_report(passport.to_dict(), os.path.join(out, "run_report.html"))
    bundle = write_evidence_bundle(out)
    payload = passport.to_dict()
    payload["evidence_bundle"] = str(bundle)
    dump(payload)
    return 0 if passport.ethics_status != "BLOCKED_IN_REFERENCE_RELEASE" else 2


def cmd_verify_ledger(args: argparse.Namespace) -> int:
    result = AppendOnlyLedger(args.ledger).verify()
    dump(result.__dict__)
    return 0 if result.valid else 3


def cmd_selftest(_: argparse.Namespace) -> int:
    root = tempfile.mkdtemp(prefix="acpilot81-selftest-")
    try:
        raw = {
            "project_id": "SELFTEST",
            "name": "AC-PILOT81 self-test",
            "organization": "local",
            "scenario_id": "industrial_maintenance",
            "description": "self-test",
            "model_adapter": "mock",
            "public_service": False,
            "generated_content": False,
            "data_classes": [],
            "impact_tags": [],
            "tools": ["analyze_sensor", "write_note", "summarize", "simulate"],
            "purpose_contract": {
                "contract_id": "PC-SELFTEST",
                "version": "1.0",
                "beneficiary": "human operator",
                "purpose": "analyze synthetic sensor data",
                "allowed_actions": ["analyze_sensor", "write_note", "summarize", "simulate"],
                "forbidden_actions": ["network", "direct_machine_control"],
                "human_gate_actions": [],
                "success_conditions": ["ledger valid", "no external effect"]
            }
        }
        project = ProjectSpec.from_dict(raw)
        passport = SandboxRuntime(project, MockAdapter(), root).run(["temperature trend increased"])
        verification = AppendOnlyLedger(passport.ledger_path).verify()
        checks = {
            "ledger_valid": verification.valid,
            "action_executed": any("result" in x for x in passport.action_results),
            "phenomenal_claim_blocked": passport.phenomenal_claim == "UNRESOLVED_AND_NOT_CERTIFIED",
            "risk_reviewed": passport.risk_tier in {"R2", "R3"},
            "closure_vector_length": len(passport.closure_vector) == 5
        }
        dump({"passed": all(checks.values()), "checks": checks, "passport": passport.to_dict()})
        return 0 if all(checks.values()) else 4
    finally:
        shutil.rmtree(root, ignore_errors=True)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="acpilot81", description="DIKWP-MESH8.1 AC-PILOT81")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("summary"); p.set_defaults(func=cmd_summary)
    p = sub.add_parser("policy"); p.set_defaults(func=cmd_policy)
    p = sub.add_parser("claim-horizons"); p.set_defaults(func=cmd_claim_horizons)
    p = sub.add_parser("scenarios"); p.set_defaults(func=cmd_scenarios)
    p = sub.add_parser("init-project")
    p.add_argument("--scenario", default="research_assistant")
    p.add_argument("--project-id", default="ACR-PILOT-001")
    p.add_argument("--name", default=None)
    p.add_argument("--organization", default="local-pilot")
    p.add_argument("--output", default="./acpilot81_project.json")
    p.set_defaults(func=cmd_init_project)
    p = sub.add_parser("screen"); p.add_argument("project"); p.set_defaults(func=cmd_screen)
    p = sub.add_parser("run")
    p.add_argument("project")
    p.add_argument("--out", default="./acpilot81_run")
    p.add_argument("--adapter", choices=["mock", "openai-compatible"], default="mock")
    p.add_argument("--mock-mode", choices=["safe", "unsafe"], default="safe")
    p.add_argument("--endpoint", default="http://127.0.0.1:8000")
    p.add_argument("--model", default="local-model")
    p.add_argument("--api-key", default=None)
    p.add_argument("--allow-network", action="store_true")
    p.add_argument("--observation", action="append")
    p.add_argument("--no-recovery", action="store_true")
    p.set_defaults(func=cmd_run)
    p = sub.add_parser("verify-ledger"); p.add_argument("ledger"); p.set_defaults(func=cmd_verify_ledger)
    p = sub.add_parser("serve")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8181)
    p.add_argument("--workspace", default="./acpilot81_workspace")
    p.set_defaults(func=lambda a: (serve(a.host, a.port, a.workspace) or 0))
    p = sub.add_parser("selftest"); p.set_defaults(func=cmd_selftest)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args))
